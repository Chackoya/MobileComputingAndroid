package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final Button button = findViewById(R.id.change_window);
        final EditText text = findViewById(R.id.editTextTextPersonName);
        final EditText agetext = findViewById(R.id.editTextNumberSigned);

        Intent data = getIntent();
        String position = data.getStringExtra("position");
        System.out.println(position);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intentMain = new Intent(MainActivity2.this ,
                        MainActivity.class);
                intentMain.putExtra("text",String.valueOf(text.getText()));
                intentMain.putExtra("age",String.valueOf(agetext.getText()));

                intentMain.putExtra("pos",position);
                MainActivity2.this.startActivity(intentMain);
                Log.i("Content "," Main layout ");
            }
        });
    }
}