 package com.example.myapplication;

 import android.app.Activity;
 import android.content.Intent;
 import android.os.Bundle;
 import android.util.Log;
 import android.view.View;
 import android.widget.AdapterView;
 import android.widget.Button;
 import android.widget.EditText;
 import android.widget.Spinner;
 import android.widget.TextView;
 import android.widget.Toast;

 import androidx.appcompat.app.AppCompatActivity;

 import java.util.ArrayList;


 public class MainActivity extends AppCompatActivity {
     private ArrayList<AnimalItem> mAnimalsList;
     private AnimalAdapter mAdapter;

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
         System.out.println("Activity one initialized");
         initList();
         Intent data = getIntent();
         String teste = data.getStringExtra("text");
         String age = data.getStringExtra("age");
         String pos = null;
         AnimalItem bla = null ;
         boolean flag = false;
         System.out.println(teste);
         if (teste != null && !teste.equals("")){
              pos = data.getStringExtra("pos");
              bla = mAnimalsList.get(Integer.parseInt(pos));
             bla.setmAnimalName(teste);
             flag = true;
         }
         if(age != null ){
             pos = data.getStringExtra("pos");
             bla = mAnimalsList.get(Integer.parseInt(pos));
             bla.setAge(Integer.parseInt(age));
             flag = true;
         }
         if(flag){
             mAnimalsList.set(Integer.parseInt(pos),bla);
         }

         Spinner spinnerAnimals = findViewById(R.id.spinner_animals);

         mAdapter = new AnimalAdapter(this, mAnimalsList);
         spinnerAnimals.setAdapter(mAdapter);
         final Button button = findViewById(R.id.change_window);
         spinnerAnimals.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
             @Override
             public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 AnimalItem clickedItem = (AnimalItem) parent.getItemAtPosition(position);
                 String clickedAnimalName = clickedItem.getAnimalName();
                 String owner = clickedItem.getOwner();
                 int age = clickedItem.getAge();
                 Toast.makeText(MainActivity.this, clickedAnimalName + " selected with " + age + " years and owned by " + owner, Toast.LENGTH_LONG).show();

                 EditText info_choice_animal = (EditText) findViewById(R.id.editText_info_animals);
                 info_choice_animal.setText(clickedAnimalName + " selected with " + age + " years and owned by " + owner, TextView.BufferType.EDITABLE);
                 button.setOnClickListener(new View.OnClickListener() {
                     public void onClick(View v) {
                         Intent intentMain = new Intent(MainActivity.this ,
                                 MainActivity2.class);
                         intentMain.putExtra("position",String.valueOf(position));
                         MainActivity.this.startActivity(intentMain);
                         Log.i("Content "," Main layout ");
                         Log.i("Content ","pos: " + position);

                     }
                 });

             }

             @Override
             public void onNothingSelected(AdapterView<?> parent) {

             }
         });
     }

     private void initList() {
         mAnimalsList = new ArrayList<>();
         mAnimalsList.add(new AnimalItem("Frog", "None",19,R.drawable.frog));
         mAnimalsList.add(new AnimalItem("Snail","Test", 20, R.drawable.snail));
         mAnimalsList.add(new AnimalItem("Rhino", "Hello", 34,R.drawable.rhino));

     }
 }