package com.example.myapplication;

public class AnimalItem {
    private String mAnimalName;
    private String owner;
    private int age;
    private int mAnimalImage;


    public AnimalItem(String mAnimalName, String owner, int age, int mAnimalImage) {
        this.mAnimalName = mAnimalName;
        this.owner = owner;
        this.age = age;
        this.mAnimalImage = mAnimalImage;
    }

    public String getAnimalName() {
        return mAnimalName;
    }

    public int getAnimalImage() {
        return mAnimalImage;
    }
    

    public String getOwner() {
        return owner;
    }

    public int getAge() {
        return age;
    }

    public void setmAnimalName(String mAnimalName) {
        this.mAnimalName = mAnimalName;
    }

    public void setAge(int age) {
        this.age = age;
    }
}